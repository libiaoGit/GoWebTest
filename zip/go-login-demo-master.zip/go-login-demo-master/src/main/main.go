package main

import (
	"action"
)

func main() {
	action.StartUp()
}