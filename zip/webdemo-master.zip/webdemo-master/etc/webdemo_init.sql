drop database webdemo;

create database webdemo;

use webdemo;

/*
������
*/

insert into webdemo_admin values(null, 'yejianfeng', 'yejianfeng');